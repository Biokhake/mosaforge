# MOSA Forge — 형태소 레지스트리 (버퍼 동결)

유사도 40% · 전신 폴리 ≤20000 · 2026-09-13

## 운영
- 신규 착수 금지 · 열린 인저리 없음 · 5% 버퍼 보존
- 레이스 예외: SRG-032 선적재 **유지·FULL** (추가 글자 금지)

## SS
| kit | arch | status |
|---|---|---|
| SSA-001 | blunt | FULL PASS 54 |
| SSB-002 | hex | FULL PASS 54 |
| SSC-003 | wedge | FULL PASS 54 |
| SSD-004 | bucket | FULL PASS 54 |

## SR
| kit | arch | status |
|---|---|---|
| SRA-026 | blunt | FULL PASS 52 |
| SRB-027 | hex | FULL PASS 52 |
| SRC-028 | wedge | FULL PASS 52 |
| SRD-029 | bucket | FULL PASS 52 |
| SRE-030 | shelf | FULL PASS 52 |
| SRF-031 | diamond | FULL PASS 52 |
| SRG-032 | split | FULL PASS 52 · filleted-split-bilobe · n=15 · poly~7424 · race keep |

## RS
| kit | arch | status |
|---|---|---|
| RSA-051 | blunt | FULL PASS 52 |
| RSB-052 | hex | FULL PASS 52 |
| RSC-053 | wedge | FULL PASS 52 |
| RSD-054 | bucket | rs-bucket-openface-cowl | FULL PASS 52 · standby |

## RR
| kit | arch | status |
|---|---|---|
| RRA-076 | blunt | FULL PASS 52 · poly~13324 |
